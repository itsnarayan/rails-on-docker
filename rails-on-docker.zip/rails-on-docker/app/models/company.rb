class Company < ApplicationRecord
  has_many :users
end
