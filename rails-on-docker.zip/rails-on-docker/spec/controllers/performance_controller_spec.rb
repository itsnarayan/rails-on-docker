require 'rails_helper'

RSpec.describe PerformanceController, type: :controller do

end
